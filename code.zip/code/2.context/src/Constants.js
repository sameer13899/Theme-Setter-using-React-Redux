const THEMES = {
  RED: 'RED',
  GREEN: 'GREEN',
};

const ZOOMING = {
  SMALL: 'small',
  LARGE: 'xx-large',
};

export { THEMES, ZOOMING };
