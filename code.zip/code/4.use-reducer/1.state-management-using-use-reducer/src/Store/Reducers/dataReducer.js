// This is a reducer
// This is how we can use multiple reducers, using combineReducers

// const data = {
//   a: 1,
//   b: 2,
// };

// export function dataReducer(data = { a: 1, b: 2 }, action) {
//   return data;
// }
